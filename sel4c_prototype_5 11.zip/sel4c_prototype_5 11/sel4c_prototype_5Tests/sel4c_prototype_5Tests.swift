//
//  sel4c_prototype_5Tests.swift
//  sel4c_prototype_5Tests
//
//  Created by Roberto Machorro on 09/10/23.
//

import XCTest
@testable import sel4c_prototype_5

final class sel4c_prototype_5Tests: XCTestCase {
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testConnectionServidor() async throws {
        var networkService = APICall()
        let apiCall = try await networkService.fetchPaises()
        XCTAssertEqual(apiCall[0].nombre_pais, "Afganistan")
    }
    
    func testCreateUser() async throws {
        var newUserTest = NuevoUsuario()
        newUserTest.apellido = "zep"
        newUserTest.disciplina = "Negocios"
        newUserTest.email = "est@gmail.com"
        newUserTest.edad = 30
        newUserTest.sexo = "Masculino"
        newUserTest.grado_academico = "Posgrado"
        newUserTest.institucion = "IBERO"
        newUserTest.nombre = "est"
        newUserTest.pais = "Mexico"
        newUserTest.password = "est"
        
        var networkService = APICall()
        
        let newUserCall = try await networkService.createUser(newUser: newUserTest)
        
        var correo: String = "est@gmail.com"
        var password: String = "est"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        XCTAssertEqual(loginCall.auth, true)
    }
    
    func testLogin() async throws {
        var correo = "J@gmail.com"
        var password = "J"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        XCTAssertEqual(loginCall.auth, true)
    }
    
    func testLoginIncorrecto() async throws {
        var correo: String = "false@gmail.com"
        var password: String = "false"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        XCTAssertEqual(loginCall.auth, false)
    }
    
    func testInsertUserResponses() async throws {
        let correo = "S@gmail.com"
        let password = "S"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        LoginController.shared.setCurrentToken(loginCall.token)
        
        var testUserResponses = Respuesta()
        testUserResponses.idpregunta = 1
        testUserResponses.idusuario = 72 // ver en api
        testUserResponses.idcuestionario = 1
        testUserResponses.idanswer = 1
        
        var respuestaArray: Respuestas = [testUserResponses]
        
        var networkService = APICall()
        let InsertResponseCall = try await networkService.insertUserResponses(respuestasArray: respuestaArray)
        print(RespuestaError.itemNotFound)
        //XCTAssertEqual(UsuarioEditadoError.itemNotFound, false )
    }
    
    func testEditUser() async throws {
        var correo: String = "est@gmail.com"
        var password: String = "est"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        
        var editUserTest = UsuarioEditado()
        editUserTest.apellido = "zep"
        editUserTest.disciplina = "Negocios"
        editUserTest.email = "est1@gmail.com"
        editUserTest.edad = 30
        editUserTest.sexo = "Masculino"
        editUserTest.grado_academico = "Posgrado"
        editUserTest.institucion = 1
        editUserTest.nombre = "est"
        editUserTest.pais = 1
        
        var networkService = APICall()
        
        let usuarioDataCambiado = try jsonEncoder.encode(editUserTest)
        print(String(data: usuarioDataCambiado, encoding: .utf8))
        let usuarioCambiado = try await networkService.editUsuario(editedUser: usuarioDataCambiado)
        
        var correo1: String = "est1@gmail.com"
        var password1: String = "est"
        let user1 = LoginUser(email: correo1, password: password1)
        let loginCall1 = try await loginRequest.loginUser(user: user1)
        XCTAssertEqual(loginCall1.auth, true)
    }
    
    func testDeleteUser() async throws {
        // LoginController.shared.setCurrentId(69)
        
        var deleteUserTest = EliminarModel()
        deleteUserTest.password = "est"
        
        var networkService = APICall()
        
        let deleteUserCall = try await networkService.deleteUsuario(password: deleteUserTest)
        
        var correo: String = "est1@gmail.com"
        var password: String = "est"
        let user = LoginUser(email: correo, password: password)
        let loginRequest = LoginController()
        let loginCall = try await loginRequest.loginUser(user: user)
        XCTAssertEqual(loginCall.auth, false)
    }
    
    func testFetchPreguntas() async throws {
        var networkService = APICall()
        let apiCall = try await networkService.fetchPreguntas()
        XCTAssertEqual(apiCall[0].pregunta, "Cuando algo me apasiona hago lo posible para lograr mis metas.")
    }
    
    func testFetchInstituciones() async throws {
        var networkService = APICall()
        let apiCall = try await networkService.fetchInstituciones()
        XCTAssertEqual(apiCall[1].nombre_institucion, "IBERO")
    }
    
    func testFetchPaises() async throws {
        var networkService = APICall()
        let apiCall = try await networkService.fetchPaises()
        XCTAssertEqual(apiCall[0].nombre_pais, "Afganistan")
    }
    
}
