//
//  LoginController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 05/10/23.
//

import Foundation

enum loginError: Error, LocalizedError{
    case itemNotFound
}

class LoginController{
    
    static let shared = LoginController()
    private var currentUserId: Int?
    private var currentToken: String?
    private var currentUser: Usuario?
    
    let baseString = "http://82.165.212.88:8000/api/usuarios/login"
    func loginUser(user:LoginUser) async throws -> loginToken{
        let loginURL = URL(string: baseString)!
        var request = URLRequest(url:loginURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(user)
        request.httpBody = jsonData
        do{
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                var loginToken = loginToken()
                print("Entro al error")
                return loginToken
                //throw loginError.itemNotFound
            }
            
            let jsonDecoder = JSONDecoder()
            let loginToken = try? jsonDecoder.decode(loginToken.self, from: data)
            //print(loginToken!.id)
            
            //Authentication
            /*
            if loginToken?.auth == true{
                currentToken = loginToken!.token
                currentUserId = loginToken!.id
                print(currentToken!)
                print(currentUserId!)
                print("Bearer \(currentToken!)")
            }*/
            
            //currentUser = try await getUsuarioFromID()
            //print("Antes del return")
            return loginToken!
        } 
    }
    
    
    func getUsuarioFromID() async throws -> Usuario{
        
        let baseString = "http://82.165.212.88:8000/api/usuarios/\(LoginController.shared.getCurrentId()!)"
        print(baseString)
        let getUsuarioURL = URL(string: baseString)!
        
        var request = URLRequest(url: getUsuarioURL)
        request.httpMethod = "GET"
        print("Bearer \(LoginController.shared.getCurrentToken())")
        request.setValue("Bearer \(LoginController.shared.getCurrentToken()!)", forHTTPHeaderField: "Authorization")
        
        let(data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else{
            throw UsuarioError.itemNotFound
        }
        //print(String(data:data, encoding: .utf8))
        
        let jsonDecoder = JSONDecoder()
        let user = try? jsonDecoder.decode(Usuario.self, from: data)
        currentUser = user!
        return user!
    }
    
    func setCurrentId(_ id: Int) {
        self.currentUserId = id
    }
    
    func setCurrentToken(_ token: String) {
        self.currentToken = token
    }
    
    func setCurrentUser(_ user: Usuario) {
        self.currentUser = user
    }
    
    func getCurrentToken() -> String? {
        return currentToken
    }
    
    func getCurrentId() -> Int? {
        return currentUserId
    }
    
    func getCurrentUser() -> Usuario? {
        return currentUser
    }
    
    
}
