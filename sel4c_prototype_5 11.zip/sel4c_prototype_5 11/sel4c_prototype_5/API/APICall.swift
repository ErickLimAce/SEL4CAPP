//
//  APICall.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 07/10/23.
//

import Foundation

class APICall{
    
    //let accessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NjEsImlhdCI6MTY5NjgzOTMwNCwiZXhwIjoxNjk2OTI1NzA0fQ.VY1dRMjyRhxaJU5a21xYpP9INN40S8IP7JeMVgfzjuk"
    let accessToken = LoginController.shared.getCurrentToken()
    //let userId = 55
    let userId = LoginController.shared.getCurrentId()

    //API request para crear un nuevo Usuario
    func createUser(newUser:NuevoUsuario) async throws -> Void{
        let baseString = "http://82.165.212.88:8000/api/usuarios/xcode"
        let createUserURL = URL(string: baseString)
        
        var request = URLRequest(url:createUserURL!)
        request.httpMethod = "POST"
        //request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(newUser)
        request.httpBody = jsonData
        
        let (data, response) = try await URLSession.shared.data(for: request)
        print(String(data:data, encoding: .utf8))
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NuevoUsuarioError.itemNotFound
        }
    }
    
    //API request para editar un usuario
    func editUsuario(editedUser: Data) async throws -> Usuario{
        let baseString = "http://82.165.212.88:8000/api/usuarios/\(userId!)/xcode"
        let editUserURL = URL(string: baseString)
        
        var request = URLRequest(url: editUserURL!)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        request.httpBody = editedUser
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw UsuarioEditadoError.itemNotFound
        }
        
        let jsonDecoder = JSONDecoder()
        let usuario = try? jsonDecoder.decode(Usuario.self, from: data)
        return usuario!
        
    }
    
    //API request para borrar usuario
    func deleteUsuario(password:EliminarModel) async throws -> Void{
        //let currentId = LoginController.shared.getCurrentId()
        //let currentToken = LoginController.shared.getCurrentToken()
        
        let baseString = "http://82.165.212.88:8000/api/usuarios/\(userId!)"
        print(baseString)
        let deleteUsuarioURL = URL(string: baseString)!
        
        var request = URLRequest(url: deleteUsuarioURL)
        request.httpMethod = "DELETE"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        
        let(data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else{
            throw EliminarError.itemNotFound
        }
    }
    
    //API request para obtener preguntas
    func fetchPreguntas() async throws -> Preguntas{
        let baseString = "http://82.165.212.88:8000/api/preguntas"
        let preguntasURL = URL(string: baseString)
        
        let(data, response) = try await URLSession.shared.data(from: preguntasURL!)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw PreguntaError.itemNotFound
        }
        let jsonDecoder = JSONDecoder()
        let preguntas = try? jsonDecoder.decode(Preguntas.self, from: data)
        return preguntas!
    }
    
    //API request para obtener instituciones
    func fetchInstituciones() async throws -> Instituciones{
        let baseString = "http://82.165.212.88:8000/api/instituciones"
        let institucionesURL = URL(string: baseString)
        
        var request = URLRequest(url: institucionesURL!)
        request.httpMethod = "GET"
        //request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw InstitucionError.itemNotFound
        }
        //print(String(data:data, encoding: .utf8))
        
        let jsonDecoder = JSONDecoder()
        let instituciones = try? jsonDecoder.decode(Instituciones.self, from: data)
        return instituciones!
    }
    
    //API request para obtener paises
    func fetchPaises() async throws -> Paises{
        let baseString = "http://82.165.212.88:8000/api/paises"
        let paisesURL = URL(string: baseString)
        
        var request = URLRequest(url: paisesURL!)
        request.httpMethod = "GET"
        //request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw PaisError.itemNotFound
        }
        //print(String(data:data, encoding: .utf8))
        
        let jsonDecoder = JSONDecoder()
        let paises = try? jsonDecoder.decode(Paises.self, from: data)
        return paises!
    }
    
    func insertUserResponses(respuestasArray:Respuestas) async throws -> Void{
        let baseString = "http://82.165.212.88:8000/api/guardarRespuestas"
        let respuestasURL = URL(string: baseString)
        
        var request = URLRequest(url: respuestasURL!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(respuestasArray)
        request.httpBody = jsonData
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw UsuarioEditadoError.itemNotFound
        }
    }
    
    func cambiarContrasena(passwords:Data) async throws -> Void {
        let baseString = "http://82.165.212.88:8000/api/usuarios/\(userId!)/password/xcode"
        let passwordURL = URL(string: baseString)
        
        var request = URLRequest(url: passwordURL!)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(accessToken!)", forHTTPHeaderField: "Authorization")
        request.httpBody = passwords
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw UsuarioEditadoError.itemNotFound
        }
    }
}
