//
//  SideMenuCell.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 01/10/23.
//

import UIKit

class SideMenuCell: UITableViewCell {

    class var identifier: String { return String(describing: self)}
    class var nib: UINib {return UINib(nibName: identifier, bundle: nil)}
    
    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = .clear
        self.iconImage.tintColor = .white
        self.titleLabel.textColor = .white
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
