//
//  SideMenuModel.swift
//  sel4c_prototype_5

import SwiftUI
import Foundation

struct SideMenuModel {
    var icon: UIImage
    var title: String
}
