//
//  Preguntas.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 07/10/23.
//

import Foundation

struct Pregunta:Codable{
    let id: Int
    let pregunta: String
}
typealias Preguntas = [Pregunta]

enum PreguntaError: Error, LocalizedError{
    case itemNotFound
}
