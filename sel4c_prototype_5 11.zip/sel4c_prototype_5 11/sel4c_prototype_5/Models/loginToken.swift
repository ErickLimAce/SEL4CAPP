//
//  loginToken.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 05/10/23.
//

import Foundation

class loginToken: Codable{
    var auth: Bool = false
    var token: String = ""
    var id: Int = 0
}
