//
//  Usuario.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 02/10/23.
//

import Foundation

struct Usuario: Codable {
    let id: Int
    let apellido, disciplina, email: String
    let edad: Int
    let sexo, grado_academico: String
    let institucion: Int
    let nombre: String
    let pais: Int
    let password: String
    let progreso: Int

    /*
    enum CodingKeys: String, CodingKey {
        case id, apellido, disciplina, email, edad, sexo
        case gradoAcademico = "grado_academico"
        case password = "contrasena"
        case institucion, nombre, pais
    }*/
    
}

enum UsuarioError: Error, LocalizedError{
    case itemNotFound
}

/*
extension Usuario {
    static func createUser(newUser:Usuario) async throws -> Void{
        let baseString = "http:://82.165.210.98:8000/api/usuarios"
        let createUserURL = URL(string: baseString)!
        
        var request = URLRequest(url:createUserURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(newUser)
        request.httpBody = jsonData
        
        let (data, response) = try await URLSession.shared.data(from: createUserURL)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw UsuarioError.itemNotFound
        }
    }
    
    /*
    func deleteUsuario() async throws -> Void{
        //let currentId = LoginController.shared.getCurrentId()
        //let currentToken = LoginController.shared.getCurrentToken()
        
        let baseString = "http:://82.165.210.98:8000/api/usuarios/\(currentId)"
        let deleteUsuarioURL = URL(string: baseString)!
        
        var request = URLRequest(url: deleteUsuarioURL)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(currentToken)", forHTTPHeaderField: "Authorization")
        
        let(data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else{
            throw UsuarioError.itemNotFound
        }
    }
    
    func editUsuario(jsonList: [String: Any]) async throws -> Void{
        let currentId = LoginController.shared.getCurrentId()
        let currentToken = LoginController.shared.getCurrentToken()
        
        let baseString = "http:://82.165.210.98:8000/api/usuarios/\(currentId)"
        let editUsuarioURL = URL(string: baseString)!
        
        var request = URLRequest(url: editUsuarioURL)
        request.httpMethod = "PUT"
        request.setValue("Bearer \(currentToken)", forHTTPHeaderField: "Authorization")
        
        let jsonData = try? JSONSerialization.data(withJSONObject: jsonList)
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let(data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else{
            throw UsuarioError.itemNotFound
        }
    }*/
    
}*/


