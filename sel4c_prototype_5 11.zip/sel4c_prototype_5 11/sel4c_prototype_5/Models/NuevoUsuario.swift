//
//  NuevoUsuario.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 06/10/23.
//

import Foundation

struct NuevoUsuario:Codable{
    var apellido: String = ""
    var disciplina: String = ""
    var email: String = ""
    var edad: Int = 0
    var sexo: String = ""
    var grado_academico: String = ""
    var institucion: String = ""
    var nombre: String = ""
    var pais: String = ""
    var password: String = ""
}

enum NuevoUsuarioError: Error, LocalizedError{
    case itemNotFound
}

/*
extension NuevoUsuario{
    func crearNuevoUsuario(newUser: NuevoUsuario) async throws -> Void {
        let baseString = "http://82.165.210.98:8000/api/usuarios/xcode"
        let newUser = URL(string: baseString)!
        var request = URLRequest(url: newUser)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(newUser)
        //print(String(data:jsonData!, encoding: .utf8))
        
        request.httpBody = jsonData
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else { throw UserResponsesError.itemNotFound}
    }
}*/
