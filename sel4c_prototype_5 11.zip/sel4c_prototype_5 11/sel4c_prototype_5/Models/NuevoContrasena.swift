//
//  NuevoContrasena.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 11/10/23.
//

import Foundation

struct NuevoContrasena:Codable{
    var password_act:String = ""
    var password_nuev:String = ""
}
