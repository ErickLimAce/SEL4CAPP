//
//  Instituciones.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 06/10/23.
//

import Foundation

class Institucion:Codable {
    let idinstitucion: Int
    let nombre_institucion: String
}
typealias Instituciones = [Institucion]

enum InstitucionError: Error, LocalizedError{
    case itemNotFound
}

/*
extension Institucion{
    
    static func fetchInstituciones() async throws -> Instituciones{
        let baseString = "http://82.165.210.98:8000/api/instituciones"
        let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MzUsImlhdCI6MTY5NjcyMjU3MiwiZXhwIjoxNjk2ODA4OTcyfQ.QIJxCqZoNn8GF0cS0JQQ10e9fUmsV4heDFEBNulsAcY"
        let institucionesURL = URL(string: baseString)!
        
        var request = URLRequest(url: institucionesURL)
        request.httpMethod = "GET"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw InstitucionError.itemNotFound
        }
        print(String(data:data, encoding: .utf8))
        
        let jsonDecoder = JSONDecoder()
        let instituciones = try? jsonDecoder.decode(Instituciones.self, from: data)
        return instituciones!
    }
}*/
