//
//  Pais.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 06/10/23.
//

import Foundation

class Pais:Codable{
    let id: Int
    let iso: String
    let nombre_pais: String
}
typealias Paises = [Pais]

enum PaisError: Error, LocalizedError{
    case itemNotFound
}

/*
extension Pais{
    static func fetchPaises() async throws -> Paises{
        let baseString = "http://82.165.210.98:8000/api/paises"
        let paisesURL = URL(string: baseString)!
        let (data, response) = try await URLSession.shared.data(from: paisesURL)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw PaisError.itemNotFound
        }
        let jsonDecoder = JSONDecoder()
        let paises = try? jsonDecoder.decode(Paises.self, from: data)
        return paises!
    }
}*/
