//
//  CuestionarioComplexityEngine.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 08/10/23.
//

import Foundation

struct CuestionarioComplexityEngine{
    var questionIndex = 0
    var preguntas=Preguntas()
    mutating func initialize(q:Preguntas){
        preguntas = q
    }
    func getTextQuestion()->String{
        return preguntas[questionIndex].pregunta
    }
    func getId()->Int{
        return preguntas[questionIndex].id
    }
    func getPreguntasCount()->Int{
        return preguntas.count
    }
    /*
    func getProgress()->Float{
        let progress = Float(questionIndex+1)/Float(questions.count)
        return progress
    }*/
    mutating func nextQuestion()->Bool{
        if questionIndex+1 < preguntas.count{
            questionIndex += 1
            return false
        }
        else{
            questionIndex=0
            return true
        }
    }
}
