//
//  Respuesta.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 07/10/23.
//

import Foundation

struct Respuesta: Codable{
    var idpregunta: Int = 0
    var idusuario: Int = 0
    var idcuestionario: Int = 0
    var idanswer: Int = 0
}
typealias Respuestas = [Respuesta]

enum RespuestaError: Error, LocalizedError{
    case itemNotFound
}
