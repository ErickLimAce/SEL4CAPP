//
//  UsuarioEditado.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 07/10/23.
//

import Foundation

class UsuarioEditado:Codable{
    var apellido: String = ""
    var disciplina: String = ""
    var email: String = ""
    var edad: Int = 0
    var sexo: String = ""
    var grado_academico: String = ""
    var institucion: Int = 0
    var nombre: String = ""
    var pais: Int = 0
}

enum UsuarioEditadoError: Error, LocalizedError{
    case itemNotFound
}


