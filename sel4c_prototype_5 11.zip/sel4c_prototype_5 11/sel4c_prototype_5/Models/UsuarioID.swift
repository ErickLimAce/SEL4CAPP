//
//  UsuarioID.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 08/10/23.
//

import Foundation

class UsuarioID:Codable{
    var id:Int
}
