//
//  LoginUser.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 05/10/23.
//

import Foundation

struct LoginUser: Codable{
    let email:String
    let password:String
}
