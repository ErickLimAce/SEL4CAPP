//
//  EliminarModel.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 08/10/23.
//

import Foundation

class EliminarModel:Codable{
    var password:String = ""
}
enum EliminarError: Error, LocalizedError{
    case itemNotFound
}
