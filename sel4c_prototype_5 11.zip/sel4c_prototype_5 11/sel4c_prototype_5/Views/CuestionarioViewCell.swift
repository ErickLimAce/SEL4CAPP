//
//  CuestionarioViewCell.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 06/10/23.
//

import UIKit

protocol CuestionarioViewCellDelegate: AnyObject{
    func optionButtonSelected(_ choice: Int)
}

class CuestionarioViewCell: UITableViewCell {

    @IBOutlet weak var option1Button: UIButton!
    @IBOutlet weak var option2Button: UIButton!
    @IBOutlet weak var option3Button: UIButton!
    @IBOutlet weak var option4Button: UIButton!
    @IBOutlet weak var option5Button: UIButton!
    
    @IBOutlet weak var preguntaLabel:UILabel!
    
    weak var delegate: CuestionarioViewCellDelegate?
    var respuesta:Int = 0
    //var respuestas = [Int]()
    var preguntaNum: Int!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func optionButtonTapped(_ sender: UIButton) {
        
        for button in [self.option1Button, self.option2Button, self.option3Button, self.option4Button, self.option5Button] {
            button!.isSelected = false
        }
        
        sender.isSelected = true
        switch sender {
        case let optionButton where optionButton.titleLabel?.text == "MuyDesacuerdo":
            //respuestas[idPregunta!] = 1
            self.respuesta = 1
        case let optionButton where optionButton.titleLabel?.text == "Desacuerdo":
            self.respuesta = 2
        case let optionButton where optionButton.titleLabel?.text == "NiAcuerdo":
            self.respuesta = 3
        case let optionButton where optionButton.titleLabel?.text == "Acuerdo":
            self.respuesta = 4
        case let optionButton where optionButton.titleLabel?.text == "MuyAcuerdo":
            self.respuesta = 5
        default:
            break
        }
        print(self.respuesta)
    }

}
