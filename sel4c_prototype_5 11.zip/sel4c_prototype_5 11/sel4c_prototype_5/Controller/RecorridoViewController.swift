//
//  RecorridoViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 09/10/23.
//

import UIKit
import AVKit
import MobileCoreServices

class RecorridoViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var imagePickerController = UIImagePickerController()
    var imageURL:URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    func goBack(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func homeButton(_ sender: UIButton) {
        goBack()
    }
    
    @IBAction func mediaButton(_ sender: UIButton) {
        imagePickerController.sourceType = .savedPhotosAlbum
        imagePickerController.delegate = self
        imagePickerController.mediaTypes = ["public.image", "public.movie"]
        present(imagePickerController, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let mediaType = info[UIImagePickerController.InfoKey.mediaType] as? String {
            if mediaType == "public.image" {
                if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                    //print("SE SELECCIONO UNA IMAGEN")
                    /*
                    Task{
                        do {
                            let data = try await MultipartRequest.sendImage(user: LoginController.shared.getCurrentUser()!.nombre, evidence_name: "actividad1", imagen: image)
                        } catch {
                            return
                        }
                    } */
                }
            } else if mediaType == "public.movie" {
                if let video = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
                    /*
                    Task{
                        do{
                            let data = try await MultipartRequest.sendVideo(user: LoginController.shared.getCurrentUser()!.nombre, evidenceName: "actividad1", videoURL: video)
                        } catch {
                            return
                        }
                    }*/
                }
            }
            picker.dismiss(animated: true, completion: nil)
        }
    }

    /*
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }*/
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
