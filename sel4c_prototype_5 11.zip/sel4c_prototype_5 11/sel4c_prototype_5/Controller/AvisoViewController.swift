//
//  AvisoViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 11/10/23.
//

import UIKit

class AvisoViewController: UIViewController {

    @IBOutlet weak var checkbox_button: UIButton!
    @IBOutlet weak var continuarButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        continuarButton.isEnabled = false
        
        
    }
    
    @IBAction func checkbox_clicked(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            continuarButton.isEnabled = false
        } else {
            sender.isSelected = true
            continuarButton.isEnabled = true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
