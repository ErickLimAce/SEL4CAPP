//
//  NewUserViewController.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 06/10/23.
//

import UIKit

class NewUserViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == institucionPicker{
            return institutionNames.count
        } else if pickerView == paisPicker{
            return paisesNames.count
        } else if pickerView == disciplinaPicker{
            return disciplinaNames.count
        } else {
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView  == institucionPicker{
            return institutionNames[row]
        } else if pickerView == paisPicker{
            return paisesNames[row]
        } else if pickerView == disciplinaPicker{
            return disciplinaNames[row]
        } else {
            return nil
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == institucionPicker{
            institucionUsuario = institutionNames[row]
        } else  if pickerView == paisPicker{
            paisUsuario = paisesNames[row]
        } else if pickerView == disciplinaPicker{
            disciplinaUsuario = disciplinaNames[row]
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range:NSRange, replacementString string: String) -> Bool {
        if textField == edadField || textField == gradoField{
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        } else {
            return true
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if  identifier == "nuevoIntoLogin"{
                return false
        } else {
            return true
        }
    }

    
    @IBOutlet weak var nombreField: UITextField!
    @IBOutlet weak var apellidoField: UITextField!
    @IBOutlet weak var correoField: UITextField!
    @IBOutlet weak var contrasenaField: UITextField!
    @IBOutlet weak var contrasenaReviewField: UITextField!
    @IBOutlet weak var edadField: UITextField!
    @IBOutlet weak var gradoField: UITextField!
    
    @IBOutlet weak var institucionPicker: UIPickerView!
    @IBOutlet weak var paisPicker: UIPickerView!
    @IBOutlet weak var disciplinaPicker: UIPickerView!
    
    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var femaleButton: UIButton!
    @IBOutlet weak var nbButton: UIButton!
    
    var instituciones = Instituciones()
    var institutionNames = [String]()
    //var institutionNames = ["TEC", "UNAM", "IBERO"]
    var institucionUsuario: String?
    
    var paises = Paises()
    var paisesNames = [String]()
    //var paisesNames = ["Australia", "Afghanistan", "Mexico"]
    var paisUsuario: String?
    
    var disciplinaNames = ["Ingenieria Y Ciencias", "Humanidades Y Educacion", "Ciencias Sociales", "Ciencias de la Salud", "Arquitectura Arte y Diseño", "Negocios"]
    var disciplinaUsuario: String?
    
    var selectedSex: String = ""
    
    var nuevoUsuario = NuevoUsuario()
    
    var usuarioCreado: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let networkService = APICall()

        maleButton.isSelected = false
        femaleButton.isSelected = false
        nbButton.isSelected = false
        
        
        self.institucionPicker.delegate = self
        self.institucionPicker.dataSource = self
        self.institucionPicker.selectRow(0, inComponent: 0, animated: false)
        
        self.paisPicker.delegate = self
        self.paisPicker.dataSource = self
        self.paisPicker.selectRow(0, inComponent: 0, animated: false)
        
        self.disciplinaPicker.delegate = self
        self.disciplinaPicker.dataSource = self
        self.disciplinaPicker.selectRow(0, inComponent: 0, animated: false)
        
        
        Task{
            do{
                instituciones = try await networkService.fetchInstituciones()
                updateUIIntituciones(with: instituciones)
                reloadInstitucionesPicker(instituciones: instituciones)
            } catch {
                displayError(InstitucionError.itemNotFound, title: "No se pudo acceder a las instituciones")
            }
        }
        
        Task{
            do{
                paises = try await networkService.fetchPaises()
                updateUIPaises(with: paises)
                reloadPaisesPicker(paises: paises)
            } catch {
                displayError(InstitucionError.itemNotFound, title: "No se pudo acceder a los paises")
            }
        }
    }
    
    func updateUIIntituciones(with instituciones:Instituciones){
        DispatchQueue.main.async{
            for institucion in instituciones{
                self.institutionNames.append(institucion.nombre_institucion)
            }
            //print(self.institutionNames)
        }
    }
    
    func updateUIPaises(with paises:Paises){
        DispatchQueue.main.async{
            for pais in paises{
                self.paisesNames.append(pais.nombre_pais)
            }
            //print(self.paisesNames)
        }
    }
    
    func reloadInstitucionesPicker(instituciones: Array<Institucion>){
        DispatchQueue.main.async {
            self.institucionPicker.reloadAllComponents()
        }
    }
    
    func reloadPaisesPicker(paises: Array<Pais>){
        DispatchQueue.main.async {
            self.paisPicker.reloadAllComponents()
        }
    }
    
    func displayError(_ error: Error, title: String){
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        }
    }
    
    @IBAction func selectMaleButton(_ sender: UIButton) {
        selectedSex = "Masculino"
        
        maleButton.isSelected = true
        femaleButton.isSelected = false
        nbButton.isSelected = false
    }
    
    @IBAction func selectFemaleButton(_ sender: UIButton) {
        selectedSex = "Femenino"
        
        maleButton.isSelected = false
        femaleButton.isSelected = true
        nbButton.isSelected = false
    }
    
    @IBAction func selectNBButton(_ sender: UIButton) {
        selectedSex = "No binario"
        
        maleButton.isSelected = false
        femaleButton.isSelected = false
        nbButton.isSelected = true
    }
    
    @IBAction func registrarButton(_ sender: UIButton) {
        let networkService = APICall()
        
        if  nombreField.text == "" || nombreField.text == "" || nombreField.text == "" || nombreField.text == "" || nombreField.text == "" || nombreField.text == "" || nombreField.text == "" || selectedSex == ""{
            let alert = UIAlertController(title: "Atención", message: "Todos los campos tienen que ser llenados", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else if contrasenaField.text != contrasenaReviewField.text{
            let alert = UIAlertController(title: "Atención", message: "Las contraseñas no coinciden", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            
            self.nuevoUsuario.nombre = nombreField.text!
            self.nuevoUsuario.apellido = apellidoField.text!
            self.nuevoUsuario.disciplina = disciplinaUsuario!
            self.nuevoUsuario.edad = Int(edadField.text!)!
            self.nuevoUsuario.email = correoField.text!
            self.nuevoUsuario.grado_academico = gradoField.text!
            self.nuevoUsuario.pais = paisUsuario!
            self.nuevoUsuario.sexo = selectedSex
            self.nuevoUsuario.institucion = institucionUsuario!
            self.nuevoUsuario.password = contrasenaField.text!
            
            print(self.nuevoUsuario)
        
        /*
        self.nuevoUsuario.nombre = "J"
        self.nuevoUsuario.apellido = "J"
        self.nuevoUsuario.disciplina = "Negocios"
        self.nuevoUsuario.edad = 16
        self.nuevoUsuario.email = "J@gmail.com"
        self.nuevoUsuario.grado_academico = "Posgrado"
        self.nuevoUsuario.pais = "Mexico"
        self.nuevoUsuario.sexo = "Femenino"
        self.nuevoUsuario.institucion = "IBERO"
        self.nuevoUsuario.password = "J"*/
        
             Task{
             do{
                 try await networkService.createUser(newUser: self.nuevoUsuario)
                 updateUserResponses(title: "Se creó el usuario exitósamente"){
                     self.doSegue()
                 }
             } catch {
             displayErrorUserResponses(NuevoUsuarioError.itemNotFound, title: "No se pudo acceder a la base de datos")
             }
             }
        }
    }

    func doSegue(){
        DispatchQueue.main.async{
            self.performSegue(withIdentifier: "nuevoIntoLogin", sender: self)
        }
    }
    func updateUserResponses(title: String, completion: @escaping () -> Void){
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: "Datos almacenados con éxito", preferredStyle: .alert)
            let continueAction = UIAlertAction(title: "Continuar", style: .default) {_ in
                completion()
            }
            alert.addAction(continueAction)
            self.present(alert,animated: true)
        }
    }
    func displayErrorUserResponses(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Continuar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
