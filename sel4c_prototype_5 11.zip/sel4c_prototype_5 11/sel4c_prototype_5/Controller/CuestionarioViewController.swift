//
//  CuestionarioViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 08/10/23.
//

import UIKit

class CuestionarioViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var cuestionarioTable: UITableView!
    var preguntas: [Pregunta] = []
    var resultados: [Respuesta] = []
    var staticId:Int = 40
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let networkService = APICall()
        
        // Do any additional setup after loading the view.
        Task{
            do{
                var questions = try await networkService.fetchPreguntas()
                preguntas = questions
                reloadTable(preguntas: preguntas)
            } catch {
                return
            }
        }
        
    }
    
    func reloadTable(preguntas: Array<Pregunta>){
        DispatchQueue.main.async {
            self.cuestionarioTable.reloadData()
        }
    }
    
    @IBAction func entregarButton(_ sender: Any) {
        saveResults()
    }
    
    
    func saveResults(){
        resultados.removeAll()

            for row in 0..<cuestionarioTable.numberOfRows(inSection: 0) {
                if let cell = cuestionarioTable.cellForRow(at: IndexPath(row: row, section: 0)) as? CuestionarioViewCell {
                    var respuestaNueva = Respuesta()
                    respuestaNueva.idanswer = cell.respuesta
                    respuestaNueva.idpregunta = cell.preguntaNum
                    respuestaNueva.idcuestionario = 1
                    //respuestaNueva.idusuario = LoginController.shared.getCurrentUser()!.id
                    respuestaNueva.idusuario = staticId
                    resultados.append(respuestaNueva)
                }
            }
        print("FINISHED")
        print(resultados)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return preguntas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "questionCell", for: indexPath) as! CuestionarioViewCell
        cell.preguntaLabel.text = preguntas[indexPath.row].pregunta
        cell.preguntaNum = preguntas[indexPath.row].id
        
        cell.option1Button.isSelected = false
        cell.option2Button.isSelected = false
        cell.option3Button.isSelected = false
        cell.option4Button.isSelected = false
        cell.option5Button.isSelected = false
        
        switch cell.respuesta{
        case 1:
            cell.option1Button.isSelected = true
        case 2:
            cell.option2Button.isSelected = true
        case 3:
            cell.option3Button.isSelected = true
        case 4:
            cell.option4Button.isSelected = true
        case 5:
            cell.option5Button.isSelected = true
        default:
            break
        }
        
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
