//
//  ViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 30/08/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var correoLabel: UITextField!
    
    @IBOutlet weak var contrasenaLabel: UITextField!
    
    var loginController = LoginController()
    var loginResponse = loginToken()
    
    var progresoInicial:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if  identifier == "segueLoginToA" {
            return false
        } else if identifier == "segueLoginToCuestionario"{
            return false
        } else if identifier == "segueLoginToB"{
            return false
        } else {
            return true
        }
    }
    
    @IBAction func buttonConfirmar(_ sender: UIButton) {
        let correo = correoLabel?.text
        let contrasena = contrasenaLabel?.text
        
        let user = LoginUser(email: correo!, password: contrasena!)
        
        if correoLabel.text == "" || contrasenaLabel.text == "" {
            print("ALERT DE DATOS")
        } else {
            Task{
                do{
                    loginResponse = try await loginController.loginUser(user: user.self)
                    authUser(token: loginResponse)
                    confirmUser(token:loginResponse.auth)
                } catch {
                    displayError(loginError.itemNotFound, title: "No se pudo acceder")
                }
            }
        }
    }
    
    func displayError(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    func authUser(token: loginToken){
        DispatchQueue.main.async{
            if token.auth == true {
                LoginController.shared.setCurrentId(token.id)
                LoginController.shared.setCurrentToken(token.token)
            }
        }
    }
    
    func confirmUser(token:Bool){
        DispatchQueue.main.async {
            if token == true {
                //self.performSegue(withIdentifier: "segueLoginToA", sender: self)
                print("LOGIN")
                Task {
                    do{
                        let usuario = try await self.loginController.getUsuarioFromID()
                        //print(usuario.nombre)
                        //self.progresoInicial = usuario.progreso
                        LoginController.shared.setCurrentUser(usuario)
                        self.confirmSegues(usuario: usuario)
                    } catch {
                        self.displayError(loginError.itemNotFound, title: "No se pudo acceder")
                    }
                }
                /*
                let prog = LoginController.shared.getCurrentUser()!.progreso
                print(prog)
                if prog == 0{
                    self.performSegue(withIdentifier: "segueLoginToCuestionario", sender: self)
                } else {
                    self.performSegue(withIdentifier: "segueLoginToA", sender: self)
                }*/
            } else {
                let alert = UIAlertController(title: "Usuario no encontrado", message: "El correo o contraseña que introdujo son incorrectos. Favor de verificar los datos.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("NO LOGIN")
            }
        }
    }
    
    func confirmSegues(usuario:Usuario){
        DispatchQueue.main.async{
            self.progresoInicial = usuario.progreso
            print(self.progresoInicial)
            if self.progresoInicial == 0 {
                self.performSegue(withIdentifier: "segueLoginToCuestionario", sender: self)
            } else if self.progresoInicial <= 3{
                self.performSegue(withIdentifier: "segueLoginToA", sender: self)
            } else if self.progresoInicial <= 6{
                self.performSegue(withIdentifier: "segueLoginToB", sender: self)
            }
            //self.performSegue(withIdentifier: "segueLoginToA", sender: self)
        }
    }
    
}

