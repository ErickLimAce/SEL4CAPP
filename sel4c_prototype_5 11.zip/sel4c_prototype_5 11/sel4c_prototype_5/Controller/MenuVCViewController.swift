//
//  MenuVCViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 30/08/23.
//

import UIKit

class MenuVCViewController: UIViewController {
    
    
    
    /*
    @IBOutlet weak var progBar: UIProgressView!
    */
    
    @IBOutlet weak var buttonNivel: UIButton!
    @IBOutlet weak var buttonConfig: UIButton!
    
    @IBOutlet weak var lluviaButton: UIButton!
    @IBOutlet weak var entrevistaButton: UIButton!
    @IBOutlet weak var recorridoButton: UIButton!
    
    @IBOutlet weak var concluirButton: UIButton!
    @IBOutlet weak var actButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lluviaView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.entrevistaView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.recorridoView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.lluviaButton.isEnabled = false
        self.entrevistaButton.isEnabled = false
        self.recorridoButton.isEnabled = false
        
        self.concluirButton.isHidden = true
        
        //progBar.transform = progBar.transform.scaledBy(x: 1, y: 1)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //var usuarioId:Int = LoginController.shared.getCurrentId()!
        var networkUpdate = LoginController()
        
        Task{
            do {
                LoginController.shared.setCurrentUser(try await networkUpdate.getUsuarioFromID())
                updateView()
            } catch {
                return
            }
        }
         
    }
    
    func updateView(){
        DispatchQueue.main.async {
            var progreso:Int = LoginController.shared.getCurrentUser()!.progreso
            print(progreso)

            // Do any additional setup after loading the view.
            //setPupopButton()
            
            let lightGreen = UIColor(red: 234/255, green: 254/255, blue: 242/255, alpha: 1)
            let darkGreen = UIColor(red: 50/255, green: 115/255, blue: 60/255, alpha: 1)
            
            self.navigationItem.hidesBackButton = true
            self.lluviaView.layer.borderWidth = 2
            self.lluviaView.layer.borderColor = UIColor.black.cgColor
            self.entrevistaView.layer.borderWidth = 2
            self.entrevistaView.layer.borderColor = UIColor.black.cgColor
            self.recorridoView.layer.borderWidth = 2
            self.recorridoView.layer.borderColor = UIColor.black.cgColor
            
            self.buttonNivel.layer.borderWidth = 1
            self.buttonNivel.layer.borderColor = UIColor.white.cgColor
            self.buttonConfig.layer.borderWidth = 1
            self.buttonConfig.layer.borderColor = UIColor.white.cgColor
            
            self.concluirButton.isHidden = true
            
            
            if progreso <= 1{
                self.lluviaView.backgroundColor = lightGreen
                self.lluviaButton.setTitleColor(darkGreen, for: .normal)
                self.entrevistaView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
                self.recorridoView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
                
                self.lluviaButton.isEnabled = true
                
                self.entrevistaButton.isEnabled = false
                self.entrevistaButton.setTitleColor(UIColor.gray, for: .normal)
                self.recorridoButton.isEnabled = false
                self.recorridoButton.setTitleColor(UIColor.gray, for: .normal)
            } else if progreso == 2 {
                self.lluviaView.backgroundColor = lightGreen
                self.lluviaButton.setTitleColor(darkGreen, for: .normal)
                self.entrevistaView.backgroundColor = lightGreen
                self.entrevistaButton.setTitleColor(darkGreen, for: .normal)
                self.recorridoView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)

                self.lluviaButton.isEnabled = true
                self.entrevistaButton.isEnabled = true
                
                self.recorridoButton.isEnabled = false
                self.recorridoButton.setTitleColor(UIColor.gray, for: .normal)
            } else if progreso == 3 {
                self.lluviaView.backgroundColor = lightGreen
                self.lluviaButton.setTitleColor(darkGreen, for: .normal)
                self.entrevistaView.backgroundColor = lightGreen
                self.entrevistaButton.setTitleColor(darkGreen, for: .normal)
                self.recorridoView.backgroundColor = lightGreen
                self.recorridoButton.setTitleColor(darkGreen, for: .normal)
                
                self.lluviaButton.isEnabled = true
                self.entrevistaButton.isEnabled = true
                self.recorridoButton.isEnabled = true
                
            } else {
                self.lluviaView.backgroundColor = lightGreen
                self.lluviaButton.setTitleColor(darkGreen, for: .normal)
                self.entrevistaView.backgroundColor = lightGreen
                self.entrevistaButton.setTitleColor(darkGreen, for: .normal)
                self.recorridoView.backgroundColor = lightGreen
                self.recorridoButton.setTitleColor(darkGreen, for: .normal)
                
                self.lluviaButton.isEnabled = true
                self.entrevistaButton.isEnabled = true
                self.recorridoButton.isEnabled = true
                
                self.concluirButton.isHidden = false
                self.concluirButton.isEnabled = true
            }
            
            var menuItems: [UIAction] = []
            let optionClosure = {(action : UIAction) in
                print(action.title)}
            if progreso >= 1 {
                menuItems.append(UIAction(title: "1. Identificación", state: .on, handler: optionClosure))
                if progreso >= 5 {
                    menuItems.append(UIAction(title: "2. Investigación", state: .on, handler: optionClosure))
                    if progreso >= 8{
                        menuItems.append(UIAction(title: "3. Ideación", state: .on, handler: optionClosure))
                    }
                }
            }
            
            self.actButton.menu = UIMenu(children:menuItems)
            self.actButton.showsMenuAsPrimaryAction = true
            self.actButton.changesSelectionAsPrimaryAction = true
            
        }
    }
    
    /*
    var menuItems: [UIAction] = []
    
    func setPupopButton(){
        let optionClosure = {(action : UIAction) in
            print(action.title)}
        var menuItems: [UIAction] = []
        
        if progreso
        
        actButton.menu = UIMenu(children : [
            UIAction(title : "Actividad 1", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 2", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 3", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 4", state : .on, handler: optionClosure),
            UIAction(title : "Entrega Final", state : .on, handler: optionClosure)])
        actButtons.showsMenuAsPrimaryAction = true
        actButtons.changesSelectionAsPrimaryAction = true
    }*/
    
    @IBOutlet weak var lluviaView: UIView!
    @IBOutlet weak var entrevistaView: UIView!
    @IBOutlet weak var recorridoView: UIView!
    


}

