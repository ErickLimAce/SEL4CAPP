//
//  CuestionarioListViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 08/10/23.
//

import UIKit

class CuestionarioListViewController: UIViewController {

    
    @IBOutlet weak var muyDesacuerdoButton: UIButton!
    @IBOutlet weak var desacuerdoButton: UIButton!
    @IBOutlet weak var niAcuerdoButton: UIButton!
    @IBOutlet weak var acuerdoButton: UIButton!
    @IBOutlet weak var muyAcuerdoButton: UIButton!
    
    @IBOutlet weak var preguntaLabel: UILabel!
    
    
    var engine = CuestionarioComplexityEngine()
    var respuestas = Respuestas()
    var staticId:Int = LoginController.shared.getCurrentId()!
    
    var networkService = APICall()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(staticId)
        
        // Do any additional setup after loading the view.
        Task{
            do{
                let preguntas = try await networkService.fetchPreguntas()
                updateUI(with: preguntas)
            }catch{
                displayError(PreguntaError.itemNotFound, title: "No se pudo accer a las preguntas")
            }
        }
    }
    
    func updateUI(with preguntas:Preguntas){
        self.engine.initialize(q: preguntas)
        print(String(self.engine.getId()))
        preguntaLabel.text = self.engine.getTextQuestion()
    }
    
    func displayError(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    
    @IBAction func usuarioRespuesta(_ sender: UIButton) {
        
        let respuestaChosen = sender.tag
        print(respuestaChosen)
        var respuesta = Respuesta(idpregunta: engine.getId(), idusuario: staticId, idcuestionario: 1, idanswer: 0)
        switch respuestaChosen{
        case 1:
            respuesta.idanswer = 1
        case 2:
            respuesta.idanswer = 2
        case 3:
            respuesta.idanswer = 3
        case 4:
            respuesta.idanswer = 4
        case 5:
            respuesta.idanswer = 5
        default:
            break
        }
        respuestas.append(respuesta)
        sender.isSelected = true
        
        muyAcuerdoButton.isEnabled = false
        acuerdoButton.isEnabled = false
        niAcuerdoButton.isEnabled = false
        desacuerdoButton.isEnabled = false
        muyDesacuerdoButton.isEnabled = false
        
        if engine.nextQuestion(){
            Task{
                do{
                    print("FIN DEL CUESTIONARIO")
                    /*
                    let jsonEncoder = JSONEncoder()
                    jsonEncoder.outputFormatting = .prettyPrinted
                    let respuestasJson = try? jsonEncoder.encode(respuestas)*/
                    
                    //print(String(data:respuestasJson!, encoding: .utf8)!)
                    try await networkService.insertUserResponses(respuestasArray: respuestas)
                    updateUserResponses(title: "Las respuestas fueron almacenas con éxito en el servidor")
                    segueIntoMenu()
                }catch{
                    displayErrorUserResponses(RespuestaError.itemNotFound, title: "No se pudo accer almacenar las respuestas en la base de datos")
                }
            }
        }else{
            Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: Selector("nextQuestion"), userInfo: nil, repeats: false)
        }
    }
    
    func updateUserResponses(title: String){
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: "Datos almacenados con éxito", preferredStyle: .alert)
            let continueAction = UIAlertAction(title: "Continuar", style: .default)
            alert.addAction(continueAction)
            self.present(alert,animated: true)
        }
    }
    func displayErrorUserResponses(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Continuar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    @objc func nextQuestion() {
        preguntaLabel.text = engine.getTextQuestion()
        muyAcuerdoButton.isSelected = false
        acuerdoButton.isSelected = false
        niAcuerdoButton.isSelected = false
        desacuerdoButton.isSelected = false
        muyDesacuerdoButton.isSelected = false
        
        muyAcuerdoButton.isEnabled = true
        acuerdoButton.isEnabled = true
        niAcuerdoButton.isEnabled = true
        desacuerdoButton.isEnabled = true
        muyDesacuerdoButton.isEnabled = true
        }
    
    func segueIntoMenu(){
        self.performSegue(withIdentifier: "segueCuestionarioMenu", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
