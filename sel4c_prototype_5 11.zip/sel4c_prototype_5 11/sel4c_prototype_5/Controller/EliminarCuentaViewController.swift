//
//  EliminarCuentaViewController.swift
//  sel4c_prototype_5
//
//  Created by Usuario on 07/10/23.
//

import UIKit

class EliminarCuentaViewController: UIViewController {

    
    @IBOutlet weak var contrasenaInput: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func eliminarCuentaButton(_ sender: Any) {
        let networkService = APICall()
        let eliminarPswrd = EliminarModel()
        
        eliminarPswrd.password = contrasenaInput.text!
        Task{
            do{
                try await networkService.deleteUsuario(password: eliminarPswrd)
            }catch{
                displayError(PreguntaError.itemNotFound, title: "Datos incorrectos")
            }
        }
    }
    
    func displayError(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
