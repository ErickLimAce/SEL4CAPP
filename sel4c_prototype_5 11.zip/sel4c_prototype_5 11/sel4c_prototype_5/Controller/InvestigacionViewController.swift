//
//  InvestigacionViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 11/10/23.
//

import UIKit

class InvestigacionViewController: UIViewController {

    @IBOutlet weak var buttonNivel: UIButton!
    @IBOutlet weak var buttonConfig: UIButton!
    
    @IBOutlet weak var odsView: UIView!
    @IBOutlet weak var situacionView: UIView!
    @IBOutlet weak var arbolCausas: UIView!
    
    @IBOutlet weak var odsButton: UIButton!
    @IBOutlet weak var situacionButton: UIButton!
    @IBOutlet weak var arbolCausasButton: UIButton!
    
    @IBOutlet weak var concluirButton: UIButton!
    @IBOutlet weak var actButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.odsView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.situacionView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.arbolCausas.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
        self.odsButton.isEnabled = false
        self.situacionButton.isEnabled = false
        self.arbolCausasButton.isEnabled = false
        
        self.concluirButton.isHidden = true
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var networkUpdate = LoginController()
        
        Task{
            do {
                LoginController.shared.setCurrentUser(try await networkUpdate.getUsuarioFromID())
                updateView()
            } catch {
                return
            }
        }
    }
    
    func updateView(){
        DispatchQueue.main.async {
            var progreso:Int = LoginController.shared.getCurrentUser()!.progreso
            print(progreso)

            // Do any additional setup after loading the view.
            //setPupopButton()
            
            let lightGreen = UIColor(red: 234/255, green: 254/255, blue: 242/255, alpha: 1)
            let darkGreen = UIColor(red: 50/255, green: 115/255, blue: 60/255, alpha: 1)
            
            self.navigationItem.hidesBackButton = true
            self.odsView.layer.borderWidth = 2
            self.odsView.layer.borderColor = UIColor.black.cgColor
            self.situacionView.layer.borderWidth = 2
            self.situacionView.layer.borderColor = UIColor.black.cgColor
            self.arbolCausas.layer.borderWidth = 2
            self.arbolCausas.layer.borderColor = UIColor.black.cgColor
            
            self.buttonNivel.layer.borderWidth = 1
            self.buttonNivel.layer.borderColor = UIColor.white.cgColor
            self.buttonConfig.layer.borderWidth = 1
            self.buttonConfig.layer.borderColor = UIColor.white.cgColor
            
            self.concluirButton.isHidden = true
            
            
            if progreso <= 5{
                self.odsView.backgroundColor = lightGreen
                self.odsButton.setTitleColor(darkGreen, for: .normal)
                self.situacionView.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
                self.arbolCausas.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)
                
                self.odsButton.isEnabled = true
                
                self.situacionButton.isEnabled = false
                self.situacionButton.setTitleColor(UIColor.gray, for: .normal)
                self.arbolCausasButton.isEnabled = false
                self.arbolCausasButton.setTitleColor(UIColor.gray, for: .normal)
                
            } else if progreso == 6 {
                self.odsView.backgroundColor = lightGreen
                self.odsButton.setTitleColor(darkGreen, for: .normal)
                self.situacionView.backgroundColor = lightGreen
                self.situacionButton.setTitleColor(darkGreen, for: .normal)
                self.arbolCausas.backgroundColor = UIColor(red: 166/255, green: 166/255, blue: 166/255, alpha: 1)

                self.odsButton.isEnabled = true
                self.situacionButton.isEnabled = true
                
                self.arbolCausasButton.isEnabled = false
                self.arbolCausasButton.setTitleColor(UIColor.gray, for: .normal)
            } else if progreso == 7 {
                self.odsView.backgroundColor = lightGreen
                self.odsButton.setTitleColor(darkGreen, for: .normal)
                self.situacionView.backgroundColor = lightGreen
                self.situacionButton.setTitleColor(darkGreen, for: .normal)
                self.arbolCausas.backgroundColor = lightGreen
                self.arbolCausasButton.setTitleColor(darkGreen, for: .normal)
                
                self.odsButton.isEnabled = true
                self.situacionButton.isEnabled = true
                self.arbolCausasButton.isEnabled = true
                
                
            } else {
                self.odsView.backgroundColor = lightGreen
                self.odsButton.setTitleColor(darkGreen, for: .normal)
                self.situacionView.backgroundColor = lightGreen
                self.situacionButton.setTitleColor(darkGreen, for: .normal)
                self.arbolCausas.backgroundColor = lightGreen
                self.arbolCausasButton.setTitleColor(darkGreen, for: .normal)
                
                self.odsButton.isEnabled = true
                self.situacionButton.isEnabled = true
                self.arbolCausasButton.isEnabled = true
                
                self.concluirButton.isEnabled = true
            }
            
            var menuItems: [UIAction] = []
            let optionClosure = {(action : UIAction) in
                print(action.title)}
            if progreso >= 1 {
                menuItems.append(UIAction(title: "1. Identificación", state: .on, handler: optionClosure))
                if progreso >= 5 {
                    menuItems[0] = UIAction(title: "1. Identificación", state: .off, handler: optionClosure)
                    menuItems.append(UIAction(title: "2. Investigación", state: .on, handler: optionClosure))
                    if progreso >= 8{
                        menuItems.append(UIAction(title: "3. Ideación", state: .on, handler: optionClosure))
                    }
                }
            }
            
            self.actButton.menu = UIMenu(children:menuItems)
            self.actButton.showsMenuAsPrimaryAction = true
            self.actButton.changesSelectionAsPrimaryAction = true
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
