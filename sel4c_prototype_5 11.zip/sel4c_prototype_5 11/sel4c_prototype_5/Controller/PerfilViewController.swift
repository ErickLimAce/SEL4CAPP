//
//  PerfilViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 31/08/23.
//

import UIKit
import SwiftUI

class PerfilViewController:
    UIViewController {

    let currentId = LoginController.shared.getCurrentId()
    let currentToken = LoginController.shared.getCurrentToken()
    let currentUser = LoginController.shared.getCurrentUser()
    
    @IBOutlet weak var newNameField: UITextField!
    @IBOutlet weak var newSurnameField: UITextField!
    @IBOutlet weak var newAgeField: UITextField!
    @IBOutlet weak var newMailField: UITextField!
    @IBOutlet weak var guardarButton: UIButton!
    
    @IBOutlet weak var editMailButton: UIButton!
    @IBOutlet weak var editUserButton: UIButton!
    @IBOutlet weak var editAgeButton: UIButton!
    @IBOutlet weak var contrasenaButton: UIButton!
    
    @IBOutlet weak var nombreLabel: UILabel!
    @IBOutlet weak var apellidoLabel: UILabel!
    @IBOutlet weak var edadLabel: UILabel!
    @IBOutlet weak var correoLabel: UILabel!
    
    
    var editItem: Int = 0
    var networkUpdate = LoginController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        newNameField.isHidden = true
        newSurnameField.isHidden = true
        newAgeField.isHidden = true
        newMailField.isHidden = true
        guardarButton.isHidden = true
        
        nombreLabel.text = LoginController.shared.getCurrentUser()?.nombre
        apellidoLabel.text = LoginController.shared.getCurrentUser()?.apellido
        if let edad = LoginController.shared.getCurrentUser()?.edad {
            edadLabel.text = String(edad)
        }
        correoLabel.text = LoginController.shared.getCurrentUser()?.email
    }

    @IBAction func homeButton(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func editAge(_ sender: Any) {
        editItem = 2
        
        editUserButton.isHidden = true
        editAgeButton.isHidden = true
        editMailButton.isHidden = true
        newAgeField.isHidden = false
        guardarButton.isHidden = false
        
        contrasenaButton.isHidden = true
    }
    
    @IBAction func editMail(_ sender: Any) {
        editItem = 3
        
        editUserButton.isHidden = true
        editAgeButton.isHidden = true
        editMailButton.isHidden = true
        newMailField.isHidden = false
        guardarButton.isHidden = false
        
        contrasenaButton.isHidden = true
    }
    
    @IBAction func editUser(_ sender: Any) {
        editItem = 1
        
        editUserButton.isHidden = true
        editAgeButton.isHidden = true
        editMailButton.isHidden = true
        newNameField.isHidden = false
        newSurnameField.isHidden = false
        guardarButton.isHidden = false
        
        contrasenaButton.isHidden = true
    }
    
    @IBAction func saveChanges(_ sender: Any) {
        let networkService = APICall()
        let usuarioEditado = UsuarioEditado()
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        
        //save changed data to db
        switch editItem{
        case 1:
            print("SE EDITA EL NOMBRE/APELLIDO")
            let newApellido = newSurnameField.text
            let newNombre = newNameField.text
            
            usuarioEditado.apellido = newApellido!
            usuarioEditado.nombre = newNombre!
            
            nombreLabel.text = newNombre!
            apellidoLabel.text = newApellido!
            //Resto de los datos del usuario actual
            usuarioEditado.disciplina = LoginController.shared.getCurrentUser()!.disciplina
            usuarioEditado.email = LoginController.shared.getCurrentUser()!.email
            usuarioEditado.edad = LoginController.shared.getCurrentUser()!.edad
            usuarioEditado.sexo = LoginController.shared.getCurrentUser()!.sexo
            usuarioEditado.grado_academico = LoginController.shared.getCurrentUser()!.grado_academico
            usuarioEditado.institucion = LoginController.shared.getCurrentUser()!.institucion
            usuarioEditado.pais = LoginController.shared.getCurrentUser()!.pais
            
            Task{
                do{
                    let usuarioDataCambiado = try jsonEncoder.encode(usuarioEditado)
                    let usuarioCambiado = try await networkService.editUsuario(editedUser: usuarioDataCambiado)
                    print(usuarioCambiado.nombre)
                } catch {
                    displayError(UsuarioEditadoError.itemNotFound, title: "No se pudo acceder")
                }
            }
            
        case 2:
            print("SE EDITA LA EDAD")
            let newEdad = Int(newAgeField.text!)
            print(newEdad!)
            
            usuarioEditado.edad = newEdad!
            
            edadLabel.text = String(newEdad!)
            //Resto de los datos del usuario actual
            usuarioEditado.apellido = LoginController.shared.getCurrentUser()!.apellido
            usuarioEditado.nombre = LoginController.shared.getCurrentUser()!.nombre
            usuarioEditado.disciplina = LoginController.shared.getCurrentUser()!.disciplina
            usuarioEditado.email = LoginController.shared.getCurrentUser()!.email
            //usuarioEditado.edad = LoginController.shared.getCurrentUser()!.edad
            usuarioEditado.sexo = LoginController.shared.getCurrentUser()!.sexo
            usuarioEditado.grado_academico = LoginController.shared.getCurrentUser()!.grado_academico
            usuarioEditado.institucion = LoginController.shared.getCurrentUser()!.institucion
            usuarioEditado.pais = LoginController.shared.getCurrentUser()!.pais
            
            Task{
                do{
                    let usuarioDataCambiado = try jsonEncoder.encode(usuarioEditado)
                    print(String(data:usuarioDataCambiado, encoding: .utf8))
                    let usuarioCambiado = try await networkService.editUsuario(editedUser: usuarioDataCambiado)
                    let usuarioCambiadoJson = try jsonEncoder.encode(usuarioCambiado)
                    print(String(data:usuarioCambiadoJson, encoding: .utf8))
                } catch {
                    displayError(UsuarioEditadoError.itemNotFound, title: "No se pudo acceder")
                }
            }
        case 3:
            print("SE EDITA EL CORREO")
            let newCorreo = newMailField.text!
            
            usuarioEditado.email = newCorreo
            
            correoLabel.text = newCorreo
            //Resto de los datos del usuario actual
            usuarioEditado.apellido = LoginController.shared.getCurrentUser()!.apellido
            usuarioEditado.nombre = LoginController.shared.getCurrentUser()!.nombre
            usuarioEditado.disciplina = LoginController.shared.getCurrentUser()!.disciplina
            usuarioEditado.edad = LoginController.shared.getCurrentUser()!.edad
            usuarioEditado.edad = LoginController.shared.getCurrentUser()!.edad
            usuarioEditado.sexo = LoginController.shared.getCurrentUser()!.sexo
            usuarioEditado.grado_academico = LoginController.shared.getCurrentUser()!.grado_academico
            usuarioEditado.institucion = LoginController.shared.getCurrentUser()!.institucion
            usuarioEditado.pais = LoginController.shared.getCurrentUser()!.pais
            
            Task{
                do{
                    let usuarioDataCambiado = try jsonEncoder.encode(usuarioEditado)
                    let usuarioCambiado = try await networkService.editUsuario(editedUser: usuarioDataCambiado)
                    updateUserData()
                    print(usuarioCambiado.nombre)
                } catch {
                    displayError(UsuarioEditadoError.itemNotFound, title: "No se pudo acceder")
                }
            }
        default:
            print("NO SE EDITA NADA")
        }
        
        //Hide fields
        newNameField.isHidden = true
        newSurnameField.isHidden = true
        newAgeField.isHidden = true
        newMailField.isHidden = true
        
        guardarButton.isHidden = true
        
        //Show edit button again
        editUserButton.isHidden = false
        editAgeButton.isHidden = false
        editMailButton.isHidden = false
        
        contrasenaButton.isHidden = true
        
    }
    
    func displayError(_ error: Error, title: String) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    
    func updateUserData(){
        DispatchQueue.main.async {
            Task{
                do{
                    LoginController.shared.setCurrentUser(try await self.networkUpdate.getUsuarioFromID())
                    print(LoginController.shared.getCurrentUser())
                } catch {
                    return
                }
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
